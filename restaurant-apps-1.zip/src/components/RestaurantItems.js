class RestaurantItems extends HTMLElement {
    constructor() {
        super()
    }

    connectedCallback() {
        const id = this.getAttribute('id')
        const name = this.getAttribute('name')
        const description = this.getAttribute('description')
        const pictureId = this.getAttribute('pictureid')
        const city = this.getAttribute('city')
        const rating = this.getAttribute('rating')
        this.innerHTML = `<div id="${id}" class="resto-item" tabIndex="0">
            <div class="city">Kota ${city}</div>
            <img class="" src="${pictureId}"/>
            <div class="caption">
                <div class="rating">Rating: ${rating}</div>
                <h4 class="title">${name}</h4>
                <div>${description}</div>
            </div>
        </div>`
    }
}
export default RestaurantItems
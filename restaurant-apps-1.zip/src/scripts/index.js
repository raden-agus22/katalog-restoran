import 'regenerator-runtime'; /* for async await transpile */
import RestaurantItems from '../components/RestaurantItems';
import '../styles/main.css';
import data from '../data';

customElements.define('list-restaurant', RestaurantItems);
const listRestoDiv = document.getElementById("list-resto");

const loadData = () => { 
    data.map((val, key) => {
        let listitem = document.createElement("list-restaurant");
        listitem.setAttribute("pictureid", val.pictureId);
        listitem.setAttribute("id", val.id);
        listitem.setAttribute("city", val.city);
        listitem.setAttribute("description", val.description.substring(0, 170) + "...");
        listitem.setAttribute("name", val.name);
        listitem.setAttribute("rating", val.rating);
        listRestoDiv.appendChild(listitem);
    })
}
loadData()
const hamburgerIcon = document.getElementById("hamburger-icon");
hamburgerIcon.addEventListener('keydown', (e) => {
    if (e.key == "Enter")
        hamburgerIcon.classList.toggle('open');
})
hamburgerIcon.addEventListener('click', (e) => {
    hamburgerIcon.classList.toggle('open');
})

console.log('Hello Coders! :)');

import { restaurants } from './DATA.json';

const data = restaurants;

export default data;